"""同步串口接口，双路接收分流；显式 arm 后才启动心跳线程。

不重试电机数据。ACK 只代表 M0 接受数据，电机成功与否仍由原协议判断。
"""
from __future__ import annotations

import logging
import threading
import time

from . import protocol as p

logger = logging.getLogger(__name__)


class BridgeError(RuntimeError):
    pass


class Bridge:
    def __init__(self, port: str, *, baudrate: int = 921600) -> None:
        self.port = port
        self.baudrate = baudrate
        self._serial = None
        self._decoder = p.Decoder()
        self._sequence = 0
        self._rx = {1: bytearray(), 2: bytearray()}
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._heartbeat: threading.Thread | None = None
        self._failure: Exception | None = None
        self._armed = False

    def open(self) -> None:
        import serial

        if self._serial is not None:
            return
        self._decoder = p.Decoder()
        self._rx = {1: bytearray(), 2: bytearray()}
        self._failure = None
        self._serial = serial.Serial(
            self.port, self.baudrate, timeout=0.01, write_timeout=0.2,
            bytesize=8, parity="N", stopbits=1, rtscts=False, dsrdtr=False,
            xonxoff=False,
        )
        logger.info("桥接串口已打开：%s（输出未使能）", self.port)

    def _pump(self) -> list[p.Frame]:
        if self._serial is None:
            raise BridgeError("串口尚未打开")
        data = self._serial.read(min(512, max(1, self._serial.in_waiting)))
        replies = []
        for frame in self._decoder.feed(data):
            if frame.kind == p.RX and frame.channel in self._rx:
                queue = self._rx[frame.channel]
                if len(queue) + len(frame.payload) > 65536:
                    raise BridgeError("主机接收队列溢出；请持续读取电机回包")
                queue.extend(frame.payload)
            else:
                replies.append(frame)
        return replies

    def _request(self, kind: int, channel: int = 0, payload: bytes = b"",
                 *, ignore_failure: bool = False) -> dict:
        with self._lock:
            if self._failure is not None and not ignore_failure:
                raise BridgeError("桥接会话已失败，须关闭后重新打开") from self._failure
            if self._serial is None:
                raise BridgeError("串口尚未打开")
            self._sequence = (self._sequence + 1) & 255
            sequence = self._sequence
            packet = p.encode(p.Frame(kind, channel, sequence, payload))
            try:
                written = self._serial.write(packet)
                if written != len(packet):
                    raise BridgeError("串口未完整写入；不自动重发")
                deadline = time.monotonic() + 0.3
                while time.monotonic() < deadline:
                    for frame in self._pump():
                        if (frame.kind == p.ACK and frame.channel == channel
                                and frame.sequence == sequence
                                and len(frame.payload) >= 10
                                and frame.payload[0] == kind):
                            command, result, armed, magnet, fault, version = frame.payload[:6]
                            if result != 0:
                                raise BridgeError(
                                    f"M0 拒绝命令 0x{command:02x}，result={result}，fault={fault}"
                                )
                            expected = 124 if kind == p.DIAGNOSTICS else 10
                            if len(frame.payload) != expected:
                                raise BridgeError("M0 ACK 载荷长度不符合当前命令")
                            status = dict(armed=bool(armed), magnet=bool(magnet),
                                        fault=fault, version=version,
                                        malformed=int.from_bytes(frame.payload[6:10], "little"))
                            if kind == p.DIAGNOSTICS:
                                status["diagnostics"] = p.decode_diagnostics(frame.payload[10:])
                            return status
                raise BridgeError("等待 M0 ACK 超时；不自动重发电机命令")
            except Exception as error:
                self._failure = error
                self._stop.set()
                raise

    def status(self) -> dict:
        return self._request(p.STATUS)

    def diagnostics(self) -> dict:
        """查询逐 UART 累计错误；不清故障、不使能、不续期。旧固件明确拒绝。"""
        return self._request(p.DIAGNOSTICS)

    def arm(self) -> None:
        """调用者须先完成实际接线、标定和机械运动许可检查。"""
        if self._armed:
            raise BridgeError("会话已经使能")
        self._request(p.ARM, payload=b"ARM!")
        self._armed = True
        self._stop.clear()
        self._heartbeat = threading.Thread(
            target=self._heartbeat_loop, name="m0-heartbeat", daemon=True)
        self._heartbeat.start()

    def _heartbeat_loop(self) -> None:
        while not self._stop.wait(0.2):
            try:
                self._request(p.HEARTBEAT)
            except Exception:
                logger.exception("M0 心跳失败，停止续期")
                self._stop.set()

    def write(self, channel: int, data: bytes) -> int:
        if channel not in (1, 2):
            raise ValueError("通道必须为 1（XYZ）或 2（旋转）")
        if not self._armed:
            raise BridgeError("尚未显式使能")
        for start in range(0, len(data), p.MAX_PAYLOAD):
            self._request(p.DATA, channel, bytes(data[start:start + p.MAX_PAYLOAD]))
        return len(data)

    def read(self, channel: int, size: int = 128, *, timeout: float = 0.05) -> bytes:
        if channel not in (1, 2) or size < 1 or timeout < 0:
            raise ValueError("通道、长度或超时无效")
        deadline = time.monotonic() + timeout
        while True:
            with self._lock:
                if self._failure is not None:
                    raise BridgeError("桥接会话已失败") from self._failure
                if self._serial is None:
                    raise BridgeError("串口尚未打开")
                if self._rx[channel]:
                    result = bytes(self._rx[channel][:size])
                    del self._rx[channel][:size]
                    return result
                try:
                    self._pump()
                except Exception as error:
                    self._failure = error
                    self._stop.set()
                    raise
            if time.monotonic() >= deadline:
                with self._lock:
                    result = bytes(self._rx[channel][:size])
                    del self._rx[channel][:size]
                    return result
            time.sleep(0.001)

    def set_magnet(self, enabled: bool) -> None:
        if type(enabled) is not bool:
            raise TypeError("enabled 必须为 bool")
        self._request(p.MAGNET, payload=bytes((enabled,)))

    def disarm(self) -> None:
        self._stop.set()
        if self._heartbeat is not None:
            self._heartbeat.join(timeout=1)
            self._heartbeat = None
        try:
            self._request(p.DISARM, ignore_failure=True)
        finally:
            self._armed = False

    def close(self) -> None:
        try:
            if self._armed and self._serial is not None:
                self.disarm()
        finally:
            self._stop.set()
            if self._serial is not None:
                self._serial.close()
                self._serial = None

    def __enter__(self) -> Bridge:
        self.open()
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()
