"""地猛星桥接客户端；导入不会打开串口或使能输出。"""
from .client import Bridge, BridgeError

__all__ = ["Bridge", "BridgeError"]
