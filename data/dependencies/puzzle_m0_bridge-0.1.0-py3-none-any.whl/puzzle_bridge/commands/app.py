from __future__ import annotations

import json
import logging
import typer
from puzzle_bridge import Bridge

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
app = typer.Typer(help="地猛星桥接工具；命令行仅查询状态，不使能输出。")


@app.command()
def status(
    port: str = typer.Option(..., "--port", envvar="M0_BRIDGE_PORT", help="稳定串口路径或 COM 号"),
    baudrate: int = typer.Option(921600, "--baudrate", envvar="M0_BRIDGE_BAUDRATE"),
) -> None:
    with Bridge(port, baudrate=baudrate) as bridge:
        typer.echo(json.dumps(bridge.status(), ensure_ascii=False))


@app.callback()
def main() -> None:
    pass


@app.command()
def diagnostics(
    port: str = typer.Option(..., "--port", envvar="M0_BRIDGE_PORT"),
    baudrate: int = typer.Option(921600, "--baudrate", envvar="M0_BRIDGE_BAUDRATE"),
) -> None:
    """查询开机以来各 UART 的错误类型、次数和发生时间；不清故障。"""
    with Bridge(port, baudrate=baudrate) as bridge:
        typer.echo(json.dumps(bridge.diagnostics(), ensure_ascii=False))


if __name__ == "__main__":
    app()
