"""与 MCU 共用的版本 1 帧格式。"""
from __future__ import annotations

import binascii
import struct
from dataclasses import dataclass

MAX_PAYLOAD = 128
STATUS, ARM, DISARM, HEARTBEAT = 1, 2, 3, 4
DIAGNOSTICS = 5
DATA, MAGNET, ACK, RX = 0x10, 0x11, 0x80, 0x90


def decode_diagnostics(payload: bytes) -> dict:
    """Decode the read-only UART counters; never infer an error from fault=2 alone."""
    if len(payload) != 114 or payload[0] != 1 or payload[1] & ~7:
        raise ValueError("M0 诊断载荷长度、版本或接收通道掩码无效")
    names = ("events", "overrun", "break", "parity", "framing", "queue_full",
             "first_ms", "last_ms", "armed_events")
    ports = {}
    for index, name in enumerate(("host", "xyz", "rotation")):
        ports[name] = dict(zip(names, struct.unpack_from("<9I", payload, 6 + index * 36)))
        ports[name]["rx_enabled"] = bool(payload[1] & (1 << index))
    return dict(format=payload[0], uptime_ms=struct.unpack_from("<I", payload, 2)[0],
                ports=ports)


@dataclass(frozen=True)
class Frame:
    kind: int
    channel: int
    sequence: int
    payload: bytes


def encode(frame: Frame) -> bytes:
    if len(frame.payload) > MAX_PAYLOAD:
        raise ValueError("单帧载荷不能超过 128 字节")
    body = struct.pack("<BBBBH", 1, frame.kind, frame.channel,
                       frame.sequence, len(frame.payload)) + frame.payload
    body += struct.pack("<H", binascii.crc_hqx(body, 0xFFFF))
    escaped = bytearray(b"\x7e")
    for value in body:
        if value in (0x7D, 0x7E):
            escaped.extend((0x7D, value ^ 0x20))
        else:
            escaped.append(value)
    escaped.append(0x7E)
    return bytes(escaped)


class Decoder:
    def __init__(self) -> None:
        self.buffer = bytearray()
        self.active = False
        self.escaped = False
        self.errors = 0

    def feed(self, data: bytes) -> list[Frame]:
        frames = []
        for value in data:
            if value == 0x7E:
                if self.active and self.buffer:
                    frame = self._finish()
                    if frame is not None:
                        frames.append(frame)
                self.buffer.clear()
                self.active, self.escaped = True, False
            elif self.active:
                if self.escaped:
                    if value not in (0x5D, 0x5E):
                        self.active = False
                        self.errors += 1
                        continue
                    value ^= 0x20
                    self.escaped = False
                elif value == 0x7D:
                    self.escaped = True
                    continue
                if len(self.buffer) >= MAX_PAYLOAD + 8:
                    self.active = False
                    self.errors += 1
                else:
                    self.buffer.append(value)
        return frames

    def _finish(self) -> Frame | None:
        raw = bytes(self.buffer)
        if self.escaped or len(raw) < 8:
            self.errors += 1
            return None
        version, kind, channel, sequence, length = struct.unpack("<BBBBH", raw[:6])
        if (version != 1 or len(raw) != length + 8 or length > MAX_PAYLOAD
                or binascii.crc_hqx(raw[:-2], 0xFFFF)
                != int.from_bytes(raw[-2:], "little")):
            self.errors += 1
            return None
        return Frame(kind, channel, sequence, raw[6:-2])
